<?php
include('_inc.php');

$article_id = isset($_POST['article_id']) ? (int)$_POST['article_id'] : 0;
$user_id = isset($_POST['user_id']) ? (int)$_POST['user_id'] : 0;
$vote = 1;

if (!$article_id || !$user_id) {
    echo "Недопустимые данные.";
    exit;
}

// Получаем данные о пользователя 
$sql_user = "SELECT `id` FROM `users` WHERE `mibile` != '' and `name_lat` = ?";
$stmt_user = $connect->prepare($sql_user);
$stmt_user->bind_param("s", $user_id); // исправлено "i" на "s"
$stmt_user->execute();
$result_user = $stmt_user->get_result();
$user = $result_user->fetch_assoc();

if (!$user) {
    echo "Ошибка при голосовании.";
    exit;
}

// Получаем данные о статье
$sql = "SELECT `section_id` FROM `news_articles` WHERE `id` = ?";
$stmt = $connect->prepare($sql);
$stmt->bind_param("i", $article_id);
$stmt->execute();
$result = $stmt->get_result();
$article = $result->fetch_assoc();

if (!$article) {
    echo "Школа не найдена.";
    exit;
}

// Проверка — уже голосовал?
$sql_check = "SELECT COUNT(*) as count FROM `news_votes` WHERE `user_id` = ?";
$stmt_check = $connect->prepare($sql_check);
$stmt_check->bind_param("i", $user_id); // исправлено "ii" на "i"
$stmt_check->execute();
$result_check = $stmt_check->get_result();
$row_check = $result_check->fetch_assoc();

if ($row_check['count'] > 0) {
    echo "✅ Сиз алдын даўыс бердиңиз!";
    exit;
}

// Вставка
$sql_insert = "INSERT INTO `news_votes` (`article_id`, `cat_id`, `user_id`, `vote`) VALUES (?, ?, ?, ?)";
$stmt_insert = $connect->prepare($sql_insert);
$stmt_insert->bind_param("iiii", $article_id, $article['section_id'], $user_id, $vote);
if ($stmt_insert->execute()) {
        // Увеличиваем view_count на 1
        $sql_update_views = "UPDATE `news_articles` SET `view_count` = `view_count` + 1 WHERE `id` = ?";
        $stmt_views = $connect->prepare($sql_update_views);
        $stmt_views->bind_param("i", $article_id);
        $stmt_views->execute();
    echo "✅ Сиз даўыс бердиңиз!
            <a href='stat.php'>
                <button class='btn-load-more'>Рейтинг</button>
            </a>";
} else {
    echo "Ошибка при голосовании.
            <a href='stat.php'>
                <button class='btn-load-more'>Рейтинг</button>
            </a>";
}
?>