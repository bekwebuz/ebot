<?php
include("_inc.php");
// Получаем параметры для пагинации
$offset = isset($_GET['offset']) ? (int)$_GET['offset'] : 0;
$limit = isset($_GET['limit']) ? (int)$_GET['limit'] : 30;  // Лимит записей на запрос
$query = isset($_GET['q']) ? strtolower(trim($_GET['q'])) : '';  // Преобразуем поисковый запрос в нижний регистр
$cat = isset($_GET['cat']) ? (int)$_GET['cat'] : 0;

// Формируем SQL-запрос с фильтрацией и пагинацией
if ($cat == 0) {
    // Запрос для поиска по секциям
    if ($query == "") {
        // Если поиск пустой, загружаем все секции
        $sql = "SELECT `id`, `name` FROM `news_sections` WHERE `parent` = 0 AND `deleted_at` IS NULL ORDER BY `id` ASC LIMIT ?, ?";
        $stmt = $connect->prepare($sql);
        $stmt->bind_param("ii", $offset, $limit);
    } else {
        // Запрос для поиска по секциям с фильтрацией
        $sql = "SELECT `id`, `name` FROM `news_sections` WHERE `parent` = 0 AND `deleted_at` IS NULL AND LOWER(`name`) LIKE ? ORDER BY `id` ASC LIMIT ?, ?";
        $stmt = $connect->prepare($sql);
        $searchQuery = "%" . $query . "%";
        $stmt->bind_param("sii", $searchQuery, $offset, $limit);
    }
}elseif($query == "") {
    // Запрос для поиска по статьям в выбранной категории
    $sql = "SELECT `id`, `name`,`view_count` FROM `news_articles` WHERE `section_id` = ? ORDER BY `view_count` DESC LIMIT ?, ?";
    $stmt = $connect->prepare($sql);
    $stmt->bind_param("iii", $cat, $offset, $limit);
}else{
       // Запрос для поиска по статьям в выбранной категории
    $sql = "SELECT `id`, `name`,`view_count` FROM `news_articles` WHERE `section_id` = ? AND LOWER(`name`) LIKE ? ORDER BY `view_count` ASC LIMIT ?, ?";
    $stmt = $connect->prepare($sql);
    $searchQuery = "%" . $query . "%";
    $stmt->bind_param("isii", $cat, $searchQuery, $offset, $limit);
}

// Выполняем запрос
if ($stmt->execute()) {
    // Получаем результат
    $result = $stmt->get_result();

    // Сохраняем данные в массив
    $data = [];
    while ($row = $result->fetch_assoc()) {
        $data[] = $row;
    }

    // Возвращаем результат в формате JSON
    echo json_encode($data);
} else {
    // Обработка ошибок, если запрос не выполнен
    echo json_encode(["error" => "Ошибка выполнения запроса."]);
}

// Закрытие соединения
$stmt->close();
$connect->close();
?>