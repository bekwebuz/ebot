<?php
include('_inc.php');

$user_id = isset($_GET['user_id']) ? (int)$_GET['user_id'] : 0;

$response = ['voted' => false];

if ($user_id > 0) {
    $sql = "SELECT COUNT(*) as count FROM news_votes WHERE user_id = ?";
    $stmt = $connect->prepare($sql);
    $stmt->bind_param("i", $user_id);
    $stmt->execute();
    $result = $stmt->get_result();
    $row = $result->fetch_assoc();

    if ($row['count'] > 0) {
        $response['voted'] = true;
    }
}

header('Content-Type: application/json');
echo json_encode($response);