<?php
include('_inc.php');
header('Content-Type: application/json');

$user_id = isset($_POST['user_id']) ? (int)$_POST['user_id'] : 0;
$section_id = isset($_POST['section_id']) && $_POST['section_id'] !== 'all' ? (int)$_POST['section_id'] : null;
$offset = isset($_POST['offset']) ? (int)$_POST['offset'] : 0;
$limit = 25;

$response = [
    'user_vote' => null,
    'top_schools' => [],
    'user_section_id' => null,
];

if ($user_id) {
    // Голос пользователя
    $sql_vote = "SELECT 
                    a.id AS article_id, 
                    a.name AS article_name, 
                    a.section_id,
                    s.name AS section_name
                 FROM news_votes v
                 JOIN news_articles a ON v.article_id = a.id
                 JOIN news_sections s ON a.section_id = s.id
                 WHERE v.user_id = ?
                 LIMIT 1";
    $stmt = $connect->prepare($sql_vote);
    $stmt->bind_param("i", $user_id);
    $stmt->execute();
    $result = $stmt->get_result();
    if ($vote = $result->fetch_assoc()) {
        $response['user_vote'] = $vote;
        $response['user_section_id'] = $vote['section_id'];
    }

    // Топ школ
    if ($section_id) {
        $sql_top = "SELECT a.name, a.view_count, s.name AS section_name
                    FROM news_articles a
                    JOIN news_sections s ON a.section_id = s.id
                    WHERE a.section_id = ?
                    ORDER BY a.view_count DESC
                    LIMIT ? OFFSET ?";
        $stmt_top = $connect->prepare($sql_top);
        $stmt_top->bind_param("iii", $section_id, $limit, $offset);
        $stmt_top->execute();
        $res_top = $stmt_top->get_result();
    } else {
        $sql_top = "SELECT a.name, a.view_count, s.name AS section_name
                    FROM news_articles a
                    JOIN news_sections s ON a.section_id = s.id
                    ORDER BY a.view_count DESC
                    LIMIT ? OFFSET ?";
        $stmt_top = $connect->prepare($sql_top);
        $stmt_top->bind_param("ii", $limit, $offset);
        $stmt_top->execute();
        $res_top = $stmt_top->get_result();
    }

    while ($row = $res_top->fetch_assoc()) {
        $response['top_schools'][] = $row;
    }
}

echo json_encode($response);
