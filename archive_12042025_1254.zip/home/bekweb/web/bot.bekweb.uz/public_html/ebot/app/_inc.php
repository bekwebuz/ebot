<?php
ini_set('display_errors', 1);
error_reporting(E_ALL);
date_default_timezone_set('Asia/Tashkent');

$db_host = isset($db_host) ? $db_host : 'localhost';
$db_user = isset($db_user) ? $db_user : 'bekweb_bekweb';
$db_pass = isset($db_pass) ? $db_pass : 'Bekweb@70770';
$db_name = isset($db_name) ? $db_name : 'bekweb_bekweb';

// Используем MySQLi для подключения
$connect = new mysqli($db_host, $db_user, $db_pass, $db_name);
if ($connect->connect_error) {
    // Покажем ошибку подключения
    die('Error: ' . $connect->connect_error);
}

$connect->set_charset("utf8mb4");  // Установим кодировку

define('API_KEY', "7284418290:AAE9qaICLIIooMAhgfzDB5jHeDR2qkFPLjU");

function send($method, $datas = []) {
    $url = "https://api.telegram.org/bot" . API_KEY . "/" . $method;
    $ch = curl_init();

    curl_setopt($ch, CURLOPT_URL, $url);
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
    curl_setopt($ch, CURLOPT_POSTFIELDS, $datas);
    curl_setopt($ch, CURLOPT_HTTPHEADER, [
        "Content-Type: multipart/form-data"
    ]);

    $res = curl_exec($ch);

    // Обработка ошибок cURL
    if (curl_error($ch)) {
        echo 'cURL Error: ' . curl_error($ch);
        curl_close($ch);
        return false;
    } else {
        curl_close($ch);
        return json_decode($res, true);
    }
}

function checkSubscription($channelId, $userId) {
    $url = "https://api.telegram.org/bot".API_KEY."/getChatMember?chat_id=$channelId&user_id=$userId";

    $response = file_get_contents($url);
    $data = json_decode($response, true);

    if ($data['ok'] && isset($data['result']) && $data['result']['status'] !== 'left' && $data['result']['status'] !== 'kicked') {
        return true; // Пользователь подписан
    }

    return false; // Пользователь не подписан
}

$channels = [
    ['title' => '«НЕ ЖАҢАЛЫҚ?» каналы', 'url' => 'https://t.me/ne_janaliq', 'id' => -1001663483822],
    ['title' => '«KarPressa» каналы', 'url' => 'https://t.me/KarPressa', 'id' => -1001684718975],
    ['title' => '«Нукус ОПТОМ Ноутбуки» каналы', 'url' => 'https://t.me/nukus_notebook', 'id' => -1001900000000],
];

?>