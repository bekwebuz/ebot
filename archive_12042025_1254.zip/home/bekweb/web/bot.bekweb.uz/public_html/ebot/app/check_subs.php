<?php
include('inc.php');

$data = json_decode(file_get_contents('php://input'), true);
$user_id = $data['user_id'];
$channels = $data['channels'];

$notSubscribed = [];

foreach ($channels as $ch) {
    if (!checkSubscription($ch['id'], $user_id)) {
        $notSubscribed[] = $ch;
    }
}

echo json_encode($notSubscribed);